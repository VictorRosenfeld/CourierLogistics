﻿
namespace LogisticsService.ServiceParameters
{
    /// <summary>
    /// Функциональные параметры сервиса
    /// </summary>
    public class FunctionalParameters
    {
        /// <summary>
        /// Миниальное число рабочих часов курьера
        /// </summary>
        public double min_work_time { get; set; }

        /// <summary>
        /// Интервал времени до истечения отгрузки курьером
        /// </summary>
        public double courier_alert_interval { get; set; }

        /// <summary>
        /// Интервал времени до истечения отгрузки на такси
        /// </summary>
        public double taxi_alert_interval { get; set; }

        /// <summary>
        /// Максимальное число заказов среди которых
        /// ищется оптимальное
        /// </summary>
        public int max_orders_for_search_solution { get; set; }

        /// <summary>
        /// Максимальное число заказов в задаче коммивояжера
        /// </summary>
        public int max_orders_at_traveling_salesman_problem { get; set; }

        /// <summary>
        /// Интервал опроса сервера, мсек
        /// </summary>
        public int data_request_interval { get; set; }

        /// <summary>
        /// Интервал времени для выборки событий очереди при срабатывании таймера, мсек
        /// </summary>
        public int event_time_interval { get; set; }

        /// <summary>
        /// Максимальное число точек, для которых расчитываются координаты
        /// (число заказов + число магазинов, к которым они относятся)
        /// </summary>
        public int max_points_number { get; set; }

        /// <summary>
        /// Корневой URL
        /// </summary>
        public string api_root { get; set; }
    }
}
