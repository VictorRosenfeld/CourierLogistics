﻿
namespace LogisticsService.API
{
    using Newtonsoft.Json;
    using System;
    using System.IO;
    using System.Net;
    using System.Text;

    /// <summary>
    /// Команда/рекомендация на отгрузку
    /// </summary>
    public class BeginShipment
    {
        /// <summary>
        /// URL Post запроса
        /// </summary>
        private const string URL = "{0}delivery-job";

        /// <summary>
        /// Передача отгрузки
        /// </summary>
        /// <param name="shipment">Отгрузка</param>
        /// <returns>0 - запрос успешно выполнен; иначе - выполнить запрос не удалось</returns>
        public static int Begin(Shipment shipment)
        {
            // 1. Инициализация
            int rc = 1;

            try
            {
                // 2. Проверяем исходные данные
                rc = 2;
                if (shipment == null)
                    return rc;

                // 3. Строим Post-запрос
                rc = 3;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(string.Format(URL, RequestParameters.API_ROOT));
                request.Method = "POST";
                request.UserAgent = RequestParameters.USER_AGENT;
                request.Accept = RequestParameters.HEADER_ACCEPT;
                request.ContentType = RequestParameters.HEADER_CONTENT_TYPE;
                request.Headers.Add(RequestParameters.HEADER_AUTHORIZATION);
                request.Timeout = RequestParameters.TIMEOUT;
                request.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;
                Helper.WriteToLog(request.Address.AbsolutePath);

                string postData;
                JsonSerializer serializer = JsonSerializer.Create();
                using (StringWriter sw = new StringWriter())
                {
                    serializer.Serialize(sw, new Shipment[] { shipment });
                    sw.Close();
                    postData = sw.ToString();
                }

                Helper.WriteToLog(postData);

                byte[] byteArray = Encoding.UTF8.GetBytes(postData);
                request.ContentLength = byteArray.Length;

                using (Stream dataStream = request.GetRequestStream())
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);
                    dataStream.Close();
                }

                // 4. Посылаем Post-запрос и обрабатываем отклик
                rc = 4;
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    if (response.StatusCode != HttpStatusCode.OK)
                        throw new HttpListenerException((int)response.StatusCode, response.StatusDescription);

                    using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                    {

                        //PostResponse rsp = (PostResponse)serializer.Deserialize(reader, typeof(PostResponse));
                        PostResponse rsp;
                        string json = reader.ReadToEnd();
                        Helper.WriteToLog(json);
                        
                        using (StringReader sr = new StringReader(json))
                        {
                            rsp = (PostResponse)serializer.Deserialize(reader, typeof(PostResponse));
                        }

                        if (rsp == null)
                            return rc;
                        if (rsp.result != 0)
                            return rc = 10000 * rc + rsp.result;
                    }
                }

                // 5. Выход - Ok
                rc = 0;
                return rc;
            }
            catch
            {
                return rc;
            }
        }

        /// <summary>
        /// Передача отгрузки
        /// </summary>
        /// <param name="shipment">Отгрузка</param>
        /// <returns>0 - запрос успешно выполнен; иначе - выполнить запрос не удалось</returns>
        public static int Begin(Shipment[] shipment)
        {
            // 1. Инициализация
            int rc = 1;

            try
            {
                // 2. Проверяем исходные данные
                rc = 2;
                if (shipment == null || shipment.Length <= 0)
                    return rc;

                // 3. Строим Post-запрос
                rc = 3;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(string.Format(URL, RequestParameters.API_ROOT));
                request.Method = "POST";
                request.UserAgent = RequestParameters.USER_AGENT;
                request.Accept = RequestParameters.HEADER_ACCEPT;
                request.ContentType = RequestParameters.HEADER_CONTENT_TYPE;
                request.Headers.Add(RequestParameters.HEADER_AUTHORIZATION);
                request.Timeout = RequestParameters.TIMEOUT;
                request.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;

                string postData;
                JsonSerializer serializer = JsonSerializer.Create();
                using (StringWriter sw = new StringWriter())
                {
                    serializer.Serialize(sw, shipment);
                    sw.Close();
                    postData = sw.ToString();
                }

                Helper.WriteToLog(postData);

                byte[] byteArray = Encoding.UTF8.GetBytes(postData);
                request.ContentLength = byteArray.Length;

                using (Stream dataStream = request.GetRequestStream())
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);
                    dataStream.Close();
                }

                // 4. Посылаем Post-запрос и обрабатываем отклик
                rc = 4;
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    if (response.StatusCode != HttpStatusCode.OK)
                        throw new HttpListenerException((int)response.StatusCode, response.StatusDescription);

                    using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                    {
                        //string json = reader.ReadToEnd();
                        PostResponse rsp = (PostResponse)serializer.Deserialize(reader, typeof(PostResponse));
                        if (rsp == null)
                            return rc;
                        if (rsp.result != 0)
                            return rc = 10000 * rc + rsp.result;
                    }
                }

                // 5. Выход - Ok
                rc = 0;
                return rc;
            }
            catch
            {
                return rc;
            }
        }

        /// <summary>
        /// Отгрузка
        /// </summary>
        public class Shipment
        {
            /// <summary>
            /// Id отгрузки (Guid)
            /// </summary>
            public string id { get; set; }

            /// <summary>
            /// Тип отгрузки
            /// 0 - команда на отгрузку
            /// 1 - рекомендуемая отгрузка
            /// </summary>
            public int status { get; set; }

            /// <summary>
            /// Id магазина, их которого осуществляется отгрузка
            /// </summary>
            public int shop_id { get; set; }

            /// <summary>
            /// Тип курьера
            /// 4  - пеший, вело или авто
            /// 12 - Gett-такси
            /// 14 - Yandex-такси
            /// </summary>
            public int delivery_service_id { get; set; }

            /// <summary>
            /// Id курьера
            /// (имеет смысл для 12 и 14; для 12 - 0; для 14 - 1)
            /// </summary>
            public int courier_id { get; set; }

            /// <summary>
            /// Назначенное время отгрузки
            /// </summary>
            public DateTime date_target { get; set; }

            /// <summary>
            /// Предельное время отгрузки для доставки в срок
            /// </summary>
            public DateTime date_target_end { get; set; }

            /// <summary>
            /// Id заказов, образующих отгрузку
            /// </summary>
            public int[] orders { get; set; }

            /// <summary>
            /// Количество заказов
            /// </summary>
            [JsonIgnore]
            public int Count => orders == null ? 0 : orders.Length;
        }

        /// <summary>
        /// Post-отклик
        /// </summary>
        private class PostResponse
        {
            /// <summary>
            /// Код отклика
            /// </summary>
            public int result { get; set; }
        }
    }
}
