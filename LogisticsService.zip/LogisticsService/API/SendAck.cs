﻿
namespace LogisticsService.API
{
    using Newtonsoft.Json;
    using System.IO;
    using System.Net;

    /// <summary>
    /// Подтверждение получения события
    /// </summary>
    public class SendAck
    {
        /// <summary>
        /// URL Post запроса
        /// </summary>
        private const string URL = "https://telegram.it-stuff.ru/POService/hs/test/events/{0}/received";

        /// <summary>
        /// Подтверждение получения события
        /// </summary>
        /// <param name="eventId"Id подтверждаемого события</param>
        /// <returns>0 - запрос успешно выполнен; иначе - выполнить запрос не удалось</returns>
        public static int Send(int eventId)
        {
            // 1. Инициализация
            int rc = 1;

            try
            {
                // 2. Проверяем исходные данные
                rc = 2;

                // 3. Строим Post-запрос
                rc = 3;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(string.Format(URL, eventId));
                request.Method = "POST";
                request.UserAgent = RequestParameters.USER_AGENT;
                request.Accept = RequestParameters.HEADER_ACCEPT;
                request.ContentType = RequestParameters.HEADER_CONTENT_TYPE;
                request.Headers.Add(RequestParameters.HEADER_AUTHORIZATION);
                request.Timeout = RequestParameters.TIMEOUT;
                request.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;

                request.ContentLength = 0;

                // 4. Посылаем Post-запрос и обрабатываем отклик
                rc = 4;
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    if (response.StatusCode != HttpStatusCode.OK)
                        throw new HttpListenerException((int)response.StatusCode, response.StatusDescription);

                    using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                    {
                        //string json = reader.ReadToEnd();
                        JsonSerializer serializer = JsonSerializer.Create();
                        PostResponse rsp = (PostResponse)serializer.Deserialize(reader, typeof(PostResponse));
                        if (rsp == null)
                            return rc;
                        if (rsp.result != 0)
                            return rc = 10000 * rc + rsp.result;
                    }
                }

                // 5. Выход - Ok
                rc = 0;
                return rc;
            }
            catch
            {
                return rc;
            }
        }

        /// <summary>
        /// Post-отклик
        /// </summary>
        private class PostResponse
        {
            /// <summary>
            /// Код отклика
            /// </summary>
            public int result { get; set; }
        }
    }
}
