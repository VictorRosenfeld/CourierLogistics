﻿
namespace LogisticsService.FixedCourierService.ServiceQueue
{
    /// <summary>
    /// Тип элемента очереди
    /// </summary>
    public enum QueueItemType
    {
        /// <summary>
        /// Не определен
        /// </summary>
        None = 0,

        /// <summary>
        /// Истечение времени ожидания отгрузки курьером или такси
        /// </summary>
        CourierDeliveryAlert = 6,

        /// <summary>
        /// Истечение предельного времени отгрузки с помощью такси
        /// </summary>
        TaxiDeliveryAlert = 7,
    }

}
