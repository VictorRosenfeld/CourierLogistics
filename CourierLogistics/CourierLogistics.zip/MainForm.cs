﻿
namespace CourierLogistics
{
    using CourierLogistics.Logistics;
    using CourierLogistics.Logistics.OptimalSingleShopSolution.PermutationsRepository;
    using CourierLogistics.Logistics.RealSingleShopSolution;
    using System;
    using System.IO;
    using System.Windows.Forms;

    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void butStart_Click(object sender, EventArgs e)
        {
            //ShopStatistics stat = new ShopStatistics();
            //int rs = stat.Load(@"C:\Users\Виктор\source\repos\CourierLogistics\CourierLogistics\bin\Release\LogisticsReport8.xlsx");

            //string result = Helper.ReplaceSemicolon("1222; 743; \"ss dd ff ; kk mm\"; 723; NULL");


            //double ss = Math.Ceiling(10.0);
            //double ss1 = Math.Ceiling(10.11);

            //PermutationsGenerator generator = new PermutationsGenerator();
            //int rc1 = generator.Create(5);


            Main logistics = new Main();
            string shopsFile = Properties.Settings.Default.ShopsFile;
            string shopDeliveryTypesFile = Properties.Settings.Default.shopDeliveryTypesFile;
            string ordersFile = Properties.Settings.Default.OrdersFile;
            int rc = logistics.Create(shopsFile, shopDeliveryTypesFile, ordersFile);
        }

        private void butRealModel_Click(object sender, EventArgs e)
        {
            Main logistics = new Main();
            string shopsFile = Properties.Settings.Default.ShopsFile;
            string shopDeliveryTypesFile = Properties.Settings.Default.shopDeliveryTypesFile;
            string ordersFile = Properties.Settings.Default.OrdersFile;
            string statisticsFile = @"C:\Users\Виктор\source\repos\CourierLogistics\CourierLogistics\bin\Release\LogisticsReport10.xlsx";
            int rc = logistics.CreateReal(shopsFile, shopDeliveryTypesFile, ordersFile, statisticsFile);
        }

        private void butFloatCouriers_Click(object sender, EventArgs e)
        {
            Main logistics = new Main();
            string shopsFile = Properties.Settings.Default.ShopsFile;
            string shopDeliveryTypesFile = Properties.Settings.Default.shopDeliveryTypesFile;
            string ordersFile = Properties.Settings.Default.OrdersFile;
            string statisticsFile = @"C:\Users\Виктор\source\repos\CourierLogistics\CourierLogistics\bin\Release\LogisticsReport10.xlsx";
            int rc = logistics.CreateFloat(shopsFile, shopDeliveryTypesFile, ordersFile, statisticsFile);

        }

        private void butFloatOptimalModel_Click(object sender, EventArgs e)
        {
            Main logistics = new Main();
            string shopsFile = Properties.Settings.Default.ShopsFile;
            string ordersFile = Properties.Settings.Default.OrdersFile;
            string statisticsFile = @"C:\Users\Виктор\source\repos\CourierLogistics\CourierLogistics\bin\Release\LogisticsReport10.xlsx";
            int rc = logistics.CreateFloatOptimal(shopsFile, ordersFile, statisticsFile);
        }

        private void butCompareDistance_Click(object sender, EventArgs e)
        {
            int rc = CompareDistance(@"C:\Tz\source.csv");
        }

        private static int CompareDistance(string fileName)
        {
            // 1. Инициализация
            int rc = 1;

            try
            {
                // 2. Читаем файл целиком
                rc = 2;
                string[] rows = File.ReadAllLines(fileName);

                // 3. Сздаём имя файла результата
                rc = 3;
                string resultFile = Path.GetFileNameWithoutExtension(fileName) + "_cmp.csv";
                resultFile = Path.Combine(Path.GetDirectoryName(fileName), resultFile);

                // 4. Цикл обработки
                rc = 4;
                using (StreamWriter sw = new StreamWriter(resultFile, false))
                {
                    sw.WriteLine("id; type; latitude1; longitude1; latitude2; longitude2; y-dist; s-dist; y-duration");

                    for (int i = 1; i < rows.Length; i++)
                    {
                        //if  (i == 97634)
                        //{
                        //    i = i;
                        //}

                        // 4.1 Извлекаем строку
                        rc = 41;
                        string row = rows[i].Trim();
                        if (string.IsNullOrWhiteSpace(row))
                            continue;

                        // 4.2 Разбиваем на элементы
                        rc = 42;
                        string[] items = rows[i].Split(';');
                        if (items.Length < 12)
                            continue;

                        // 4.3 Извлекаем данные
                        rc = 43;
                        double latitude1 = Helper.ParseDouble(items[0]);
                        if (double.IsNaN(latitude1))
                            continue;
                        double longitude1 = Helper.ParseDouble(items[1]);
                        if (double.IsNaN(longitude1))
                            continue;
                        double latitude2 = Helper.ParseDouble(items[10]);
                        if (double.IsNaN(latitude2))
                            continue;
                        double longitude2 = Helper.ParseDouble(items[11]);
                        if (double.IsNaN(longitude2))
                            continue;
                        double distance = Helper.ParseDouble(items[6]);
                        if (double.IsNaN(distance))
                            continue;
                        DateTime duration = Helper.ParseDateTime(items[7]);
                        if (duration == DateTime.MinValue)
                            continue;
                        int id = Helper.ParseInt(items[3]);
                        if (id == int.MinValue)
                            continue;

                        string vtype = items[4].Trim();

                        double approxDist = 1.2 * Helper.Distance(latitude1, longitude1, latitude2, longitude2);

                        sw.WriteLine($"{id}; {vtype}; {latitude1}; {longitude1}; {latitude2}; {longitude2}; {distance}; {approxDist}; {duration.TimeOfDay}");
                    }

                    sw.Close();    
                }

                //double d = 1.2 * Helper.Distance(55.585, 37.8962, 55.563136, 37.855419);
                //double d = 1.2 * Helper.Distance(56.0247, 36.6057, 56.030517, 35.959363);

                // 5. Выход - Ok
                rc = 0;
                return rc;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Compare Distance", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return rc;
            }
        }
    }
}
